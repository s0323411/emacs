A helm interface for browsing unstaged git hunks.

Enable `helm-follow-mode' and trigger `helm-hunks' to jump around
unstaged hunks like never before.

Credits/inspiration: git-gutter+ - https://github.com/nonsequitur/git-gutter-plus/
