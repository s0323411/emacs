When you start Emacs, package Session restores various variables (e.g.,
input histories) from your last session.  It also provides a menu
containing recently changed/visited files and restores the places (e.g.,
point) of such a file when you revisit it.

For details, check <http://emacs-session.sourceforge.net/> or, if you prefer
the manual style, the documentation of functions \\[session-save-session]
and `session-store-buffer-places'.

Bug fixes, bug reports, improvements, and suggestions for the newest version
are strongly appreciated.
