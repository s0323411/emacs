This is a very simple first iteration at integrating restclient.el
and org-mode.

Requirements:
restclient.el
