This file provides commands to navigate a buffer using keywords and
headings provided by `navi-mode' and `outshine'.

navi-mode <https://github.com/tj64/navi> is a package that lets you
quickly navigate and "remotely control" buffers.

Outshine <https://github.com/tj64/outshine> is a package that lets
you organize your non-org-mode buffers with commented Org headings
and other Org features, especially useful for any kind of source
code, or any file format which supports comments.

These packages are practically developed as as single package, and
`navi-mode' requires `outshine', so they are supported here in a
single `helm-navi' package.
