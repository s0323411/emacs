The project is hosted at https://github.com/sabof/org-bullets
The latest version, and all the relevant information can be found there.
