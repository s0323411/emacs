You need to install at least one of searching tools: ag, pt, grep etc.
